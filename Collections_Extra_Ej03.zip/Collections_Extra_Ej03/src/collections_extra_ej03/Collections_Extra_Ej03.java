/*
3-Extra)
*/
package collections_extra_ej03;

import Service.Libreria;

public class Collections_Extra_Ej03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Libreria lb = new Libreria();
        lb.cargaLista();
        lb.mostrarLibros();
        //cargarlalista(lb);
        if(lb.prestarLibro()) System.out.println("Se prestó con éxito.");
        else System.out.println("No se pudió.");
        if(lb.prestarLibro()) System.out.println("Se prestó con éxito.");
        else System.out.println("No se pudió.");
        if(lb.prestarLibro()) System.out.println("Se prestó con éxito.");
        else System.out.println("No se pudió.");
        lb.mostrarLibros();
        if(lb.devolverLibro()) System.out.println("Se devolvió con éxito.");
        else System.out.println("No se pudió.");
        if(lb.devolverLibro()) System.out.println("Se devolvió con éxito.");
        else System.out.println("No se pudió.");
        if(lb.devolverLibro()) System.out.println("Se devolvió con éxito.");
        else System.out.println("No se pudió.");
        if(lb.devolverLibro()) System.out.println("Se devolvió con éxito.");
        else System.out.println("No se pudió.");
        if(lb.devolverLibro()) System.out.println("Se devolvió con éxito.");
        else System.out.println("No se pudió.");
        lb.mostrarLibros();
        
    }
    public static void cargarlalista(Libreria lb){
        for (int i = 0; i < 2; i++) {
            lb.agregarLibro();
        }
    }
}
