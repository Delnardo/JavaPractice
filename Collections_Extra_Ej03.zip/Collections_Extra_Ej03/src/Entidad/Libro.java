/*
3-Extra)
*/
package Entidad;

public class Libro {
    private String título;
    private String autor;
    private int nroEjemplares;
    private int nroEjemPrestados;

    public Libro() {
    }

    public Libro(String título, String autor, int nroEjemplares, int nroEjemPrestados) {
        this.título = título;
        this.autor = autor;
        this.nroEjemplares = nroEjemplares;
        this.nroEjemPrestados = nroEjemPrestados;
    }

    public String getTítulo() {
        return título;
    }

    public void setTítulo(String título) {
        this.título = título;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNroEjemplares() {
        return nroEjemplares;
    }

    public void setNroEjemplares(int nroEjemplares) {
        this.nroEjemplares = nroEjemplares;
    }

    public int getNroEjemPrestados() {
        return nroEjemPrestados;
    }

    public void setNroEjemPrestados(int nroEjemPrestados) {
        this.nroEjemPrestados = nroEjemPrestados;
    }

    @Override
    public String toString() {
        return "Libro{" + "t\u00edtulo=" + título + ", autor=" + autor + ", nroEjemplares=" + nroEjemplares + ", nroEjemPrestados=" + nroEjemPrestados + '}';
    }
}
