/*
3-Extra)
*/
package Service;

import Entidad.Libro;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Libreria {
    private final Scanner read = new Scanner(System.in).useDelimiter("\n");
    private final HashSet<Libro> libros = new HashSet();
    
    public void cargaLista(){
        libros.add(new Libro("El Señor de los Anillos","Tolkien", 3, 0));
        libros.add(new Libro("Un Mundo Feliz","Haley", 2, 1));
        libros.add(new Libro("1984","Orwels", 4, 2));
    }
    
    public void agregarLibro(){
        System.out.println("-------------------------");
        System.out.print("Ingrese el nombre del libro: ");
        String titulo = read.next();
        System.out.print("Ingrese el nombre del autor del libro: ");
        String autor = read.next();
        System.out.print("Ingrese la cantidad de ejemplares del libro: ");
        int ejemplares = read.nextInt();
        System.out.print("Ingrese la cantidad de ejemplares prestados del libro: ");
        int ejemplaresPrestados = read.nextInt();
        libros.add(new Libro(titulo, autor, ejemplares, ejemplaresPrestados));
    }
    
    public void mostrarLibros(){
        for (Libro libro : libros) {
            System.out.println(libro.toString());
        }
    }
    
    public boolean prestarLibro(){
        System.out.println("-------------------------");
        boolean isornot = false;
        if(libros.isEmpty()){
            System.out.println("La Librería está vacía.");
        } else {
            System.out.print("Ingrese el nombre del libro a prestar: ");
            String titulo = read.next();
            for (Iterator<Libro> iterator = libros.iterator(); iterator.hasNext();) {
                Libro l = iterator.next();
                if(l.getTítulo().equalsIgnoreCase(titulo)){
                    if (l.getNroEjemPrestados()<l.getNroEjemplares()){
                        l.setNroEjemPrestados(l.getNroEjemPrestados()+1);
                        isornot = true;
                    }
                }
            }
        }
        return isornot;
    }
    
    public boolean devolverLibro(){
        System.out.println("-------------------------");
        boolean isornot = false;
        if(libros.isEmpty()){
            System.out.println("La Librería está vacía.");
        } else {
            System.out.print("Ingrese el nombre del libro a devolver: ");
            String titulo = read.next();
            for (Iterator<Libro> iterator = libros.iterator(); iterator.hasNext();) {
                Libro l = iterator.next();
                if(l.getTítulo().equalsIgnoreCase(titulo)){
                    if (l.getNroEjemPrestados() > 0){
                        l.setNroEjemPrestados(l.getNroEjemPrestados()-1);
                        isornot = true;
                    }
                }
            }
        }
        return isornot;
    }
}
