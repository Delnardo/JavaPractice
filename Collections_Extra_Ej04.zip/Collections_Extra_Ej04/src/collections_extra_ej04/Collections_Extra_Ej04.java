/*

 */
package collections_extra_ej04;

import Service.CPService;

public class Collections_Extra_Ej04 {

    public static void main(String[] args) {
        CPService cps = new CPService();
        cps.cargarCPCity();
        cps.mostrarCPCity();
        cps.modificarCity();
        cps.mostrarCPCity();
        eliminanveces(cps);
        cps.mostrarCPCity();
        cps.buscarCityporCP();
        cps.agregarCPCity();
        cps.mostrarCPCity();
    }
    public static void eliminanveces(CPService cps){
        for (int i = 0; i < 3; i++) {
            cps.eliminarCPCity();
        }
    }
}
