/*
4-Extra)Almacena en un HashMap los códigos postales de 10 ciudades a elección de esta
página: https://mapanet.eu/index.htm. Nota: Poner el código postal sin la letra, solo el
número.
• Pedirle al usuario que ingrese 10 códigos postales y sus ciudades.
• Muestra por pantalla los datos introducidos
• Pide un código postal y muestra la ciudad asociada si existe sino avisa al usuario.
• Muestra por pantalla los datos
• Agregar una ciudad con su código postal correspondiente más al HashMap.
• Elimina 3 ciudades existentes dentro del HashMap, que pida el usuario.
• Muestra por pantalla los datos
 */
package Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CPService {
    private final Scanner read = new Scanner(System.in).useDelimiter("\n");
    private HashMap<Integer, String> listacp = new HashMap();
    
    public void agregarCPCity(){
        System.out.println("----------------------------");
        System.out.print("Ingrese el Código Postal: ");
        int cp = read.nextInt();
        System.out.print("Ingrese el nombre de la ciudad: ");
        String city = read.next();
        listacp.put(cp, city);
    }
    
    public void cargarCPCity(){
        listacp.put(9410, "Ushuaia");
        listacp.put(11800, "Montevideo");
        listacp.put(1420, "La Plata");
        listacp.put(1900, "La Plata");
        listacp.put(4000, "San Miguel de Tucumán"); 
    }
    
    public void mostrarCPCity(){
        System.out.println("----------------------------");
        for (Map.Entry<Integer, String> entry : listacp.entrySet()) {
            System.out.println("El CP " + entry.getKey() + " pertenece a la ciudad de " + entry.getValue());
        }
    }
    
    public void buscarCityporCP(){
        System.out.println("----------------------------");
        System.out.print("Ingrese el código postal de la ciudad a buscar: ");
        int cp = read.nextInt();
        boolean isornot = true;
        for (Map.Entry<Integer, String> entry : listacp.entrySet()) {
            if(entry.getKey().equals(cp)){
                System.out.println("La ciudad correspondiente al cp ingresado es: " + entry.getValue());
                isornot = false;
                break;
            }
        }
        if(isornot) System.out.println("El cp ingresado no se encuentra en la lista.");
    }
    
    public void eliminarCPCity(){
        System.out.println("----------------------------");
        if(listacp.isEmpty()){
            System.out.println("La lista se encuentra vacía.");
        }else{ 
            System.out.print("Ingrese el código postal de la ciudad a eliminar: ");
            int cp = read.nextInt();
            if(listacp.containsKey(cp)){
                listacp.remove(cp);
            }else System.out.println("El cp a eliminar no se encuentra en la lista.");
        }
    }
    
    public void modificarCity(){
        System.out.println("----------------------------");
        if(listacp.isEmpty()){
            System.out.println("La lista se encuentra vacía.");
        }else{
            System.out.print("Ingrese el código postal de la ciudad a modificar: ");
            int cp = read.nextInt();
            if(listacp.containsKey(cp)){
                System.out.print("Ingrese el nombre de la ciudad: ");
                String city = read.next();
                listacp.put(cp, city);
            }else System.out.println("El cp a modificar no se encuentra en la lista.");
        }
    }
}
