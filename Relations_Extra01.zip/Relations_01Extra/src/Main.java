
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mperdomo
 */
public class Main {

    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        Service s = new Service();

        int option;
        do {
            System.out.println("_______MENU_______");
            System.out.println("1.User load");
            System.out.println("2.Dog load");
            System.out.println("3.Adoption list");
            System.out.println("4.Adoption process");
            System.out.println("5.User visualization");
            System.out.println("6.Exit");
            System.out.print(">>>");
            option = read.nextInt();
            System.out.println(option);
            switch (option) {
                case 1:
                    s.userLoad();
                    break;
                case 2:
                    s.dogLoad();
                    break;
                case 3:
                    s.adoptionList();
                    break;
                case 4:
                    s.adoptionProcess();
                    break;
                case 5:
                    s.userVisualization();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("ERROR! Type a valid option.");
            }
        } while (option != 6);
    }
}
