
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mperdomo
 */
public class Person {

    private String name;
    private String surname;
    private int age;
    private int idNumber;
    private List<Dog> adoptedDogs;

    public Person() {
        this.adoptedDogs = new ArrayList<>(); //Inicialización en el constructor predeterminado
    }

    public Person(String name, String surname, int age, int idNumber, List<Dog> adoptedDogs) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.idNumber = idNumber;
        this.adoptedDogs = adoptedDogs != null ? adoptedDogs : new ArrayList<>(); //Inicialización en el constructor con argumentos
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    public List<Dog> getAdoptedDogs() {
        return adoptedDogs;
    }

    public void setAdoptedDogs(List<Dog> adoptedDogs) {
        this.adoptedDogs = adoptedDogs;
    }

    public void adoptDog(Dog dog) {
        this.adoptedDogs.add(dog);
    }

    @Override
    public String toString() {
        System.out.println("...................");
        return "Name=" + name + "\nSurname=" + surname + "\nAge=" + age + "\nIdNumber=" + idNumber + "\nAdoptedDogs=" + adoptedDogs;
    }
}
