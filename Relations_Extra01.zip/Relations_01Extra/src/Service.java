
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mperdomo
 */
public class Service {

    Scanner read = new Scanner(System.in).useDelimiter("\n");
    List<Person> users = new ArrayList();
    List<Dog> adoptionList = new ArrayList();

    public void dogLoad() {
        System.out.println("DOG LOAD");
        Dog d1 = new Dog("Lola", "chihuahua", 5, "small", false);
        Dog d2 = new Dog("Pepe", "pitbull", 5, "big", false);
        Dog d3 = new Dog("Coco", "bulldog", 5, "small", false);
        Dog d4 = new Dog("Beethoven", "san bernardo", 5, "big", false);

        adoptionList.add(d1);
        adoptionList.add(d2);
        adoptionList.add(d3);
        adoptionList.add(d4);
    }

    public void userLoad() {
        System.out.println("USER LOAD");
        Person p1 = new Person("Jhon", "Williams", 26, 123456, new ArrayList<>());
        Person p2 = new Person("Mary", "Williams", 26, 123456, new ArrayList<>());
        Person p3 = new Person("Edgar", "Williams", 26, 123456, new ArrayList<>());
        Person p4 = new Person("Susie", "Williams", 26, 123456, new ArrayList<>());

        users.add(p1);
        users.add(p2);
        users.add(p3);
        users.add(p4);
    }

    public void adoptionList() {
        System.out.println("ADOPTION LIST");
        adoptionList.forEach((e) -> System.out.println(e));
    }

    public void adoptionProcess() {
        System.out.println("ADOPTION PROCESS");
        System.out.print("Enter the user name >>>");
        String name = read.nextLine();
        System.out.print("Enter the surname >>>");
        String surname = read.nextLine();

        boolean userFound = false; //Flag to track if user is found

        for (Person user : users) {
            if (user.getName().equalsIgnoreCase(name) && user.getSurname().equalsIgnoreCase(surname)) {
                userFound = true; //The user is found
                System.out.print("Enter the dog name >>>");
                String d = read.nextLine();
                boolean dogFound = false; //Flag to track if dog is found

                for (Dog dog : adoptionList) {
                    if (dog.getName().equalsIgnoreCase(d) && !dog.isAdopted()) {
                        dogFound = true; //The dog is found
                        System.out.println("You can adopt " + d);
                        user.adoptDog(dog);
                        dog.setAdopted(true);
                        adoptionList.remove(dog);
                        break;
                    }
                }

                if (!dogFound) {
                    System.out.println("ERROR! Wrong name or " + d + " has been adopted.");
                }
                break; //Exit the loop after processing a user
            }
        }
        if (!userFound) {
            System.out.println("ERROR! User not found.");
        }
    }

    public void userVisualization() {
        System.out.println("USER VISUALIZATION");
//        for (Person user : users) {
//            System.out.println(user);
//        }
        users.forEach((e) -> System.out.println(e));
    }
}
