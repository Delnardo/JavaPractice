/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mperdomo
 */
public class Dog {

    private String name;
    private String dogBreed;
    private int age;
    private String size;
    private boolean adopted = false;

    public Dog() {
    }

    public Dog(String name, String dogBreed, int age, String size, boolean adopted) {
        this.name = name;
        this.dogBreed = dogBreed;
        this.age = age;
        this.size = size;
        this.adopted = adopted;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDogBreed() {
        return dogBreed;
    }

    public void setDogBreed(String dogBreed) {
        this.dogBreed = dogBreed;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public boolean isAdopted() {
        return adopted;
    }

    public void setAdopted(boolean adopted) {
        this.adopted = adopted;
    }

    @Override
    public String toString() {
        System.out.println(".....................................................................");
        return "{name=" + name + ", dogBreed=" + dogBreed + ", age=" + age + ", size=" + size + ", adopted=" + adopted + '}';
    }
}
